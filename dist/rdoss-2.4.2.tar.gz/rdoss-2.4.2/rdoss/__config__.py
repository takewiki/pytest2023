secret_id = 'AKIDTlnY2GG0UheKirlOkwsXv1qzrTothEUT'  # 替换为用户的 secretId(登录访问管理控制台获取)
secret_key = 'kCNHuGL9hyxgAQP8bmgJfkZ7QTFkyvay'