# rdoss

    This is a python package created by RDS in order to
acess the object files system.

## installation
    pip install rdoss
## objects
    this package contain 2 objects:
    one is RdBucket and RdFile
### RdBucket
    bucket object stored in qcloud.

### RdFile
    file object stored in qcloud.


## release info
    `git status`

# author
    hulilei@takewiki.com.cn